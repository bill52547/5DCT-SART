clc
% mexcuda SART_cuda.cu kernel_add.cu kernel_backprojection.cu kernel_deformation.cu kernel_division.cu kernel_initial.cu...
% kernel_projection.cu kernel_update.cu kernel_forwardDVF.cu kernel_invertDVF.cu processBar.cu -lcublas
mexcuda SART_cuda2.cu kernel_add.cu kernel_backprojection.cu kernel_deformation.cu kernel_division.cu kernel_initial.cu...
kernel_projection.cu kernel_update.cu kernel_forwardDVF.cu kernel_invertDVF.cu processBar.cu -lcublas
% mexcuda host_backprojection.cu kernel_backprojection.cu
% mexcuda host_projection.cu kernel_projection.cu