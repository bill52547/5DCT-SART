__global__ void kernel_division(float *img1, float *img, int nx, int ny, int nz);
