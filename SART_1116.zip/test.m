clear; clc
load test_data0000.mat;
iter_para.n_views(2) = uint32(1);
% para.angle = iter_para.angles(1);
% para.ai = 0;
% bp0 = host_backprojection(proj1, para);
% para.ai = single(190);
% bp10 = host_backprojection(proj1, para);
% figure;imshow3D([bp0, bp10, (bp0 - bp10)],[])
% % figure;imshow3D(bp1, []); title(num2str(para.ai));
% return;
iter_para.n_iter = uint32(1);
% para.ai = -para.ai;
% para.da = para.da * 2;
% para.db = para.db * 2;
r = 1;
para.nx = 250 * r;
para.ny = 250 * r;
para.nz = floor(158 / r / r);
zeroMat = zeros(para.nx, para.ny, para.nz, 'single');
iter_para.alpha_x = zeroMat;
iter_para.alpha_y = zeroMat;
iter_para.alpha_z = zeroMat;
iter_para.beta_x = zeroMat;
iter_para.beta_y = zeroMat;
iter_para.beta_z = zeroMat;
iter_para.const_x = zeroMat;
iter_para.const_y = zeroMat;
iter_para.const_z = zeroMat;
img0 = zeroMat;
g = gpuDevice;
reset(g);
nv = 100;
angles = single([1 : nv] / nv * 2 * pi);
load ~/Data/patient_01/img.mat
img0 = img(1 : 2 :end, 1: 2 : end, 1: 2: end);
img0 = img0 - min(img0(:));
proj = zeros(512, 384, nv,'single');
img = zeros(para.nx, para.ny, para.nz,'single');
for iv = 1 : nv
    iv
    para.angle = angles(iv);
    proj(:,:,iv) = host_projection(img0, para);
    bp = host_backprojection(proj(:,:,iv), para);
%     imshow3D(bp,[]);
    img = img + bp;
end
% imshow3D(proj,[]);
imshow3D(img,[])
return;
para.angle = iter_para.angles(1);
%%proj1 = zeros(384, 512, 'single');
% proj1 = proj1(:,:,1);
% bp1 = host_backprojection(proj1, para);
% fprintf('max(bp1(:) = %d. \n', max(bp1(:)));
% fprintf('min(bp1(:) = %d. \n', min(bp1(:)));
% figure; imshow3D(bp1,[]);return
img = SART_cuda(img0, proj1(:, end : -1 : 1), para, iter_para);
figure;imshow3D(img, [0, 10000]);
max(img(:))