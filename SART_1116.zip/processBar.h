#ifndef _PROCESSBAR_H
#define _PROCESSBAR_H
#include "mex.h"
// #include <conio.h>
void processBar(int i1, int n1, int i2, int n2);
#endif // _PROCESSBAR_H
