close all;clc
mexcuda generateProj.cu kernel_deformation.cu kernel_projection.cu kernel_forwardDVF.cu kernel_invertDVF.cu
